package com.spotlylb.admin.models

data class AuthRequest(
    val email: String,
    val password: String
)